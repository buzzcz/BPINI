package prevodnik.ts_03;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_03_01.class
             })

public class TS_03 {
  // spousti vsechny TC v teto TS
}
