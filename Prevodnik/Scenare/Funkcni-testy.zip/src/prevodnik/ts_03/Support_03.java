package prevodnik.ts_03;

import org.junit.BeforeClass;

import prevodnik.PrevodnikSupport;

public class Support_03 extends PrevodnikSupport {
  
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    PrevodnikSupport.setUpBeforeClass();
    baseUrl = "http://oks.kiv.zcu.cz/Prevodnik/Prevodnik";
    driver.get(baseUrl);
 }
  
}
