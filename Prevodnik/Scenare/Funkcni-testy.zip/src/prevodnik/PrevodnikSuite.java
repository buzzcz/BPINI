package prevodnik;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import prevodnik.ts_01.TS_01;
import prevodnik.ts_02.TS_02;
import prevodnik.ts_03.TS_03;
import prevodnik.ts_04.TS_04;
import prevodnik.ts_05.TS_05;
import prevodnik.ts_06.TS_06;
import prevodnik.ts_07.TS_07;

@RunWith(Suite.class)
@SuiteClasses({ TS_01.class, TS_02.class, TS_03.class, 
                TS_04.class, TS_05.class, TS_06.class,
                TS_07.class
             })

public class PrevodnikSuite {
  // spousti vsechny TS v teto Suite
}
