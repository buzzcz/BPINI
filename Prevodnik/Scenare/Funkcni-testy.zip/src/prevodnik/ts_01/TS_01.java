package prevodnik.ts_01;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_01_01.class, TC_01_02.class, TC_01_03.class
             })

public class TS_01 {
  // spousti vsechny TC v teto TS
}
