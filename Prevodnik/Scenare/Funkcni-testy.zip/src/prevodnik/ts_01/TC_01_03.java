package prevodnik.ts_01;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_01_03 extends Support_01 {

  @Test
  public void test_1_ZalozkaUvod() {
    baseUrl = "http://oks.kiv.zcu.cz/Prevodnik/Napoveda";
    driver.get(baseUrl);

    WebElement we = driver.findElement(By.linkText("Úvod"));
    we.click();

    we = driver.findElement(By.linkText("Úvod"));
    assertEquals("http://oks.kiv.zcu.cz/Prevodnik/Uvod", 
                 we.getAttribute("href"));
  }

  @Test
  public void test_2_TitulekStranky() {
    assertEquals("PřeVODNÍK", driver.getTitle());
  }
}
