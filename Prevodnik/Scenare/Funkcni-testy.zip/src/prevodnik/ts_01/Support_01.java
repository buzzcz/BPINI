package prevodnik.ts_01;

import org.junit.Before;
import org.junit.BeforeClass;

import prevodnik.PrevodnikSupport;

public class Support_01 extends PrevodnikSupport {
  
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    PrevodnikSupport.setUpBeforeClass();
 }
  
}
