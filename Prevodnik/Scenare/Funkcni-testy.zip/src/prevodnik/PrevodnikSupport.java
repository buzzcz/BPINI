package prevodnik;

import java.util.HashMap;
import java.util.Map;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public abstract class PrevodnikSupport {
  
  public static final String TITULEK_OKS = "Portál ZČU - Prohlížení";
  public static final String TITULEK_KIV = "Domů";
  public static final String TITULEK_ZCU = "Západočeská univerzita";
  
  public static final double EPS = 0.00001;
  
  public static final Map<String, String> nazvyVyberu;
  static {
    nazvyVyberu = new HashMap<String, String>();
    nazvyVyberu.put("cm", "cm (centimetr)");
    nazvyVyberu.put("dm", "dm (decimetr)");
    nazvyVyberu.put("ft", "ft (stopa)");
    nazvyVyberu.put("in", "in (palec)");
    nazvyVyberu.put("m",  "m (metr)");
    nazvyVyberu.put("mm", "mm (milimetr)");
    nazvyVyberu.put("yd", "yd (yard)");
  }
  
  
  protected static WebDriver driver;
  protected static String baseUrl = "http://oks.kiv.zcu.cz/Prevodnik/";

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
//    System.setProperty("webdriver.chrome.driver", 
//                       "c:/Program Files (x86)/Java/selenium/chromedriver.exe");
//    driver = new ChromeDriver();
    driver = new HtmlUnitDriver();
//    driver = new FirefoxDriver();
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    driver.quit();
  }
}
