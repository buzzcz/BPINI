package prevodnik.ts_05.ts_05_07;

import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import prevodnik.ts_05.Support_05;

public class Support_05_07 extends Support_05 {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    Support_05.setUpBeforeClass();
  }

  @Before
  public void setUp() throws Exception {
    driver.get(baseUrl);
    
    // zapis do Vstup 
    WebElement input = driver.findElement(By.id("cisloVstup"));
    input.sendKeys("1");
  }

}
