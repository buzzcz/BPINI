package prevodnik.ts_05.ts_05_07;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

@RunWith(Parameterized.class)
public class TC_05_07_01 extends Support_05_07 {
  
  @Parameters(name = "{index}: 1 {0} = {2} {1}")
  public static Collection<Object[]> trojiceDat() {
      return Arrays.asList(new Object[][] {
          {"cm", "cm", 1},
          {"cm", "dm", 0.1},
          {"cm", "ft", 0.0328083989501312},
          {"cm", "in", 0.3937007874015748},
          {"cm", "m",  0.01},
          {"cm", "mm", 10},
          {"cm", "yd", 0.0109361329833771},
          {"dm", "cm", 10},
          {"dm", "dm", 1},
          {"dm", "ft", 0.3280839895013123},
          {"dm", "in", 3.937007874015748},
          {"dm", "m",  0.1},
          {"dm", "mm", 100},
          {"dm", "yd", 0.10936132983377},
          {"ft", "cm", 30.48},
          {"ft", "dm", 3.048},
          {"ft", "ft", 1},
          {"ft", "in", 12},
          {"ft", "m",  0.3048},
          {"ft", "mm", 304.8},
          {"ft", "yd", 0.3333333333333333},
          {"in", "cm", 2.54},
          {"in", "dm", 0.254},
          {"in", "ft", 0.0833333333333333},
          {"in", "in", 1},
          {"in", "m",  0.0254},
          {"in", "mm", 25.4},
          {"in", "yd", 0.0277777777777778},
          {"m", "cm", 100},
          {"m", "dm", 10},
          {"m", "ft", 3.280839895013123},
          {"m", "in", 39.37007874015748},
          {"m", "m",  1},
          {"m", "mm", 1000},
          {"m", "yd", 1.093613298337708},
          {"mm", "cm", 0.1},
          {"mm", "dm", 0.01},
          {"mm", "ft", 0.0032808398950131},
          {"mm", "in", 0.0393700787401575},
          {"mm", "m",  0.001},
          {"mm", "mm", 1},
          {"mm", "yd", 0.0010936132983377},
          {"yd", "cm", 91.44},
          {"yd", "dm", 9.144},
          {"yd", "ft", 3},
          {"yd", "in", 36},
          {"yd", "m",  0.9144},
          {"yd", "mm", 914.4},
          {"yd", "yd", 1},
      });
  }

  @Parameter(value = 0)
  public String vstupJ;
  @Parameter(value = 1)
  public String vystupJ;
  @Parameter(value = 2)
  public double ocekavano;


  // do textoveho pole Vstup prichazi vzdy 1 ze setUp()
  @Test
  public void testKombinaceVsechPrevodu() {
    // vyber ve vstupnich jednotkach
    WebElement seznam = driver.findElement(By.name("jednotkaVstup"));
    Select jednotkaVstup = new Select(seznam);
    String vstupNazev = nazvyVyberu.get(vstupJ);
    jednotkaVstup.selectByVisibleText(vstupNazev);  

    // vyber ve vystupnich jednotkach
    seznam = driver.findElement(By.name("jednotkaVystup"));
    Select jednotkaVystup = new Select(seznam);
    String vystupNazev = nazvyVyberu.get(vystupJ);
    jednotkaVystup.selectByVisibleText(vystupNazev);  
    
    // stisk tlacitka Preved
    driver.findElement(By.name("preved")).click();

    // vyhodnoceni prevodu
    WebElement vystup = driver.findElement(By.id("cisloVystup"));
    double vysledek = Double.parseDouble(vystup.getAttribute("value"));
    assertEquals(ocekavano, vysledek, EPS);
  }

}
