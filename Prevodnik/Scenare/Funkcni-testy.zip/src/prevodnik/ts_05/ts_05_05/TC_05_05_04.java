package prevodnik.ts_05.ts_05_05;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_05_04 extends Support_05_05 {

  @Test
  public void testPrevodMNaIn() {
    double vysledek = nastavVystupniJednotkuAPreved("in");
    assertEquals(39.37007874015748, vysledek, EPS);
  }

}
