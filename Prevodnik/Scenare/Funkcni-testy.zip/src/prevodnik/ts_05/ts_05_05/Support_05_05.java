package prevodnik.ts_05.ts_05_05;

import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import prevodnik.ts_05.Support_05;

public class Support_05_05 extends Support_05 {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    Support_05.setUpBeforeClass();
  }

  @Before
  public void setUp() throws Exception {
    driver.get(baseUrl);
  }

  /**
   * Metoda vyuzivana vsemi zdedenymi TC
   * vstupni hodnota je 1
   * vstupni jednotka je nastavena na metry
   * 
   * @param jednotka zkratka jednotky ve vyberovem seznamu
   * @return vysledek prevodu
   */
  protected double nastavVystupniJednotkuAPreved(String jednotka) {
    // zapis do Vstup 
    WebElement input = driver.findElement(By.id("cisloVstup"));
    input.sendKeys("1");

    // vyber ve Vstup
    WebElement seznam = driver.findElement(By.name("jednotkaVstup"));
    Select jednotkaVstup = new Select(seznam);
    jednotkaVstup.selectByVisibleText(nazvyVyberu.get("m"));  

    // vyber ve Vystup
    seznam = driver.findElement(By.name("jednotkaVystup"));
    Select jednotkaVystup = new Select(seznam);
    jednotkaVystup.selectByVisibleText(nazvyVyberu.get(jednotka));  
    
    // stisk tlacitka Preved
    driver.findElement(By.name("preved")).click();

    // vyhodnoceni prevodu
    WebElement vystup = driver.findElement(By.id("cisloVystup"));
    double vysledek = Double.parseDouble(vystup.getAttribute("value"));

    return vysledek;
  }
}
