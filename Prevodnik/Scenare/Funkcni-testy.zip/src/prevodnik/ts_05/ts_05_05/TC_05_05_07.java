package prevodnik.ts_05.ts_05_05;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_05_07 extends Support_05_05 {

  @Test
  public void testPrevodMNaYd() {
    double vysledek = nastavVystupniJednotkuAPreved("yd");
    assertEquals(1.093613298337708, vysledek, EPS);
  }

}
