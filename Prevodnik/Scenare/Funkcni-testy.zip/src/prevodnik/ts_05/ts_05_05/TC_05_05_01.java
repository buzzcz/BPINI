package prevodnik.ts_05.ts_05_05;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_05_01 extends Support_05_05 {

  @Test
  public void testPrevodMNaCm() {
    double vysledek = nastavVystupniJednotkuAPreved("cm");
    assertEquals(100, vysledek, EPS);
  }

}
