package prevodnik.ts_05.ts_05_05;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_05_05_01.class, TC_05_05_02.class, TC_05_05_03.class, 
                TC_05_05_04.class, TC_05_05_05.class, TC_05_05_06.class, 
                TC_05_05_07.class })

public class TS_05_05 {
  // spousti vsechny TC v teto TS
}
