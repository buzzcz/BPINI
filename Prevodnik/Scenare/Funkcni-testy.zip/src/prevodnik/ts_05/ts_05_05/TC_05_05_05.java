package prevodnik.ts_05.ts_05_05;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_05_05 extends Support_05_05 {

  @Test
  public void testPrevodMNaM() {
    double vysledek = nastavVystupniJednotkuAPreved("m");
    assertEquals(1, vysledek, EPS);
  }

}
