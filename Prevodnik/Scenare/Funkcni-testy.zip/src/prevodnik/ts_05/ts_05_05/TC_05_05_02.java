package prevodnik.ts_05.ts_05_05;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_05_02 extends Support_05_05 {

  @Test
  public void testPrevodMNaDm() {
    double vysledek = nastavVystupniJednotkuAPreved("dm");
    assertEquals(10, vysledek, EPS);
  }

}
