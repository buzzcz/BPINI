package prevodnik.ts_05.ts_05_08;

import org.junit.Before;
import org.junit.BeforeClass;

import prevodnik.ts_05.Support_05;

public class Support_05_08 extends Support_05 {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    Support_05.setUpBeforeClass();
  }

  @Before
  public void setUp() throws Exception {
    driver.get(baseUrl);
  }

}
