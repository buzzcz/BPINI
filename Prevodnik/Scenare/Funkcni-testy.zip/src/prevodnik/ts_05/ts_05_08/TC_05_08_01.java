package prevodnik.ts_05.ts_05_08;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class TC_05_08_01 extends Support_05_08 {

  @Test
  public void testPrevodNuly() {
    // zapis do Vstup 
    WebElement input = driver.findElement(By.id("cisloVstup"));
    input.sendKeys("0");

    // vyber ve Vstup
    WebElement seznam = driver.findElement(By.name("jednotkaVstup"));
    Select jednotkaVstup = new Select(seznam);
    jednotkaVstup.selectByVisibleText(nazvyVyberu.get("m"));  

    // vyber ve Vystup
    seznam = driver.findElement(By.name("jednotkaVystup"));
    Select jednotkaVystup = new Select(seznam);
    jednotkaVystup.selectByVisibleText(nazvyVyberu.get("m"));  
    
    // stisk tlacitka Preved
    driver.findElement(By.name("preved")).click();

    // vyhodnoceni prevodu
    WebElement vystup = driver.findElement(By.id("cisloVystup"));
    double vysledek = Double.parseDouble(vystup.getAttribute("value"));
    assertEquals(0, vysledek, EPS);
  }
}
