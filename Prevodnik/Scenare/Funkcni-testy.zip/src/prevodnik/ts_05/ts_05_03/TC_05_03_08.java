package prevodnik.ts_05.ts_05_03;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_03_08 extends Support_05_03 {

  @Test
  public void testVstupVedeckyExponentMinus() {
    double vysledek = zapisVstupAPreved("51.0e-1");
    assertEquals(5.1, vysledek, EPS);
  }

}
