package prevodnik.ts_05.ts_05_03;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_03_01 extends Support_05_03 {

  @Test
  public void testVstupCele() {
    double vysledek = zapisVstupAPreved("5");
    assertEquals(5, vysledek, EPS);
  }

}
