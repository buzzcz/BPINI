package prevodnik.ts_05.ts_05_03;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_05_03_01.class, TC_05_03_02.class, TC_05_03_03.class, 
                TC_05_03_04.class, TC_05_03_05.class, TC_05_03_06.class, 
                TC_05_03_07.class, TC_05_03_08.class, TC_05_03_09.class })

public class TS_05_03 {
  // spousti vsechny TC v teto TS
}
