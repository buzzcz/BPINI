package prevodnik.ts_05.ts_05_03;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_03_07 extends Support_05_03 {

  @Test
  public void testVstupVedeckyExponentPlus() {
    double vysledek = zapisVstupAPreved("0.51E+1");
    assertEquals(5.1, vysledek, EPS);
  }

}
