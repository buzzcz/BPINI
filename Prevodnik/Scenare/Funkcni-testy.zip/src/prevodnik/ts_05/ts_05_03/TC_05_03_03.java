package prevodnik.ts_05.ts_05_03;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_03_03 extends Support_05_03 {

  @Test
  public void testVstupDesetinneCarka() {
    double vysledek = zapisVstupAPreved("5,1");
    assertEquals(5.1, vysledek, EPS);
  }

}
