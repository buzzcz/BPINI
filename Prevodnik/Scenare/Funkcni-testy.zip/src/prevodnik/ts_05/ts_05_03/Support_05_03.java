package prevodnik.ts_05.ts_05_03;

import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import prevodnik.ts_05.Support_05;

public class Support_05_03 extends Support_05 {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    Support_05.setUpBeforeClass();
  }

  @Before
  public void setUp() throws Exception {
    driver.get(baseUrl);
  }

  /**
   * Metoda vyuzivana vsemi zdedenymi TC
   * obe jednotky jsou nastaveny na metry
   * 
   * @param vstup vstupni hodnota
   * @return vysledek prevodu
   */
  protected double zapisVstupAPreved(String vstup) {
    // zapis do Vstup 
    WebElement input = driver.findElement(By.id("cisloVstup"));
    input.sendKeys(vstup);

    String jednotka = nazvyVyberu.get("mm");

    // vyber ve Vstup
    WebElement seznam = driver.findElement(By.name("jednotkaVstup"));
    Select jednotkaVstup = new Select(seznam);
    jednotkaVstup.selectByVisibleText(jednotka);  

    // vyber ve Vystup
    seznam = driver.findElement(By.name("jednotkaVystup"));
    Select jednotkaVystup = new Select(seznam);
    jednotkaVystup.selectByVisibleText(jednotka);  
    
    // stisk tlacitka Preved
    driver.findElement(By.name("preved")).click();

    // vyhodnoceni prevodu
    WebElement vystup = driver.findElement(By.id("cisloVystup"));
    double vysledek = Double.parseDouble(vystup.getAttribute("value"));

    return vysledek;
  }
}
