package prevodnik.ts_05.ts_05_01;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_05_01_01.class, TC_05_01_02.class })

public class TS_05_01 {
  // spousti vsechny TC v teto TS
}
