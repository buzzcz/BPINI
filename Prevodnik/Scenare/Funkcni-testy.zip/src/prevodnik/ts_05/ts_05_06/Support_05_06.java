package prevodnik.ts_05.ts_05_06;

import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import prevodnik.ts_05.Support_05;

public class Support_05_06 extends Support_05 {
  public static final double PREDCHOZI_PREVOD = 12.3;
  
  // driver je nutno nastavit jen jednou, aby chybova stranka vydrzela i pro druhy test
  // nastavi se predchozi spravny vstup
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    Support_05.setUpBeforeClass();
    driver.get(baseUrl);
    
    // nastavi se predchozi spravny vstup
    String jednotka = nazvyVyberu.get("m");

    // vyber ve Vstup
    WebElement seznam = driver.findElement(By.name("jednotkaVstup"));
    Select jednotkaVstup = new Select(seznam);
    jednotkaVstup.selectByVisibleText(jednotka);  

    // vyber ve Vystup
    seznam = driver.findElement(By.name("jednotkaVystup"));
    Select jednotkaVystup = new Select(seznam);
    jednotkaVystup.selectByVisibleText(jednotka);  

    // zapis do Vstup predchozi prevod
    WebElement input = driver.findElement(By.id("cisloVstup"));
    input.sendKeys("" + PREDCHOZI_PREVOD);
    
    // stisk tlacitka Preved
    driver.findElement(By.name("preved")).click();
  }

  /**
   * Metoda vyuzivana vsemi zdedenymi TC
   * obe jednotky jsou nastaveny na metry
   * 
   * @param vstup vstupni hodnota
   * @return podrobne chybove hlaseni
   */
  protected String zapisChybnyVstupAPreved(String vstup) {
    // zapis do Vstup aktualni prevod
    WebElement input = driver.findElement(By.id("cisloVstup"));
    input.clear();
    input.sendKeys(vstup);
    
    // stisk tlacitka Preved
    driver.findElement(By.name("preved")).click();

    // vyhodnoceni prevodu
    WebElement chyboveHlaseni = driver.findElement(By.id("chyba_0"));
    String vysledek = chyboveHlaseni.getText();

    return vysledek;
  }
}
