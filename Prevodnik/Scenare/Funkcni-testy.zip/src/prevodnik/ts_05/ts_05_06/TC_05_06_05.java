package prevodnik.ts_05.ts_05_06;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_05_06_05 extends Support_05_06 {

  @Test
  public void test_1_VstupPrazdnaHodnota() {
    String hlaseni = zapisChybnyVstupAPreved("");
    assertEquals("Nebylo zadáno žádné číslo pro převod.", hlaseni);
  }

  @Test
  public void test_2_KontrolaChybovehoVypisu() {
    WebElement chyboveHlaseni = driver.findElement(By.id("chyba"));
    assertEquals("Nelze převést", chyboveHlaseni.getText());
  }

  @Test
  public void test_3_VystupMaBytVymazan() {
    WebElement vystup = driver.findElement(By.id("cisloVystup"));
    boolean vystupVymazan;
    if (vystup.getAttribute("value").trim().length() == 0) {
      vystupVymazan = true;
    }
    else {
      vystupVymazan = false;
    }
    assertTrue("Nebyl vymazan vystup", vystupVymazan);
  }
}
