package prevodnik.ts_05.ts_05_06;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_05_06_01 extends Support_05_06 {

  @Test
  public void test_1_VstupZaporneCele() {
    String hlaseni = zapisChybnyVstupAPreved("-5");
    assertEquals("Zadané číslo je záporné.", hlaseni);
  }

  @Test
  public void test_2_KontrolaChybovehoVypisu() {
    WebElement chyboveHlaseni = driver.findElement(By.id("chyba"));
    assertEquals("Nelze převést", chyboveHlaseni.getText());
  }

  @Test
  public void test_3_PrevodNemaBytProveden() {
    WebElement vystup = driver.findElement(By.id("cisloVystup"));
    double vysledek = Double.parseDouble(vystup.getAttribute("value"));
    boolean prevodProveden = (vysledek != PREDCHOZI_PREVOD) ? true : false;
    assertFalse("Proveden prevod zaporneho cisla:", prevodProveden);
  }

}
