package prevodnik.ts_05.ts_05_06;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_05_06_01.class, TC_05_06_02.class, TC_05_06_03.class, 
                TC_05_06_04.class, TC_05_06_05.class, TC_05_06_06.class })

public class TS_05_06 {
  // spousti vsechny TC v teto TS
}
