package prevodnik.ts_05.ts_05_04;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_04_01 extends Support_05_04 {

  @Test
  public void testPrevodCmNaM() {
    double vysledek = nastavVstupniJednotkuAPreved("cm");
    assertEquals(0.01, vysledek, EPS);
  }

}
