package prevodnik.ts_05.ts_05_04;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_04_07 extends Support_05_04 {

  @Test
  public void testPrevodYdNaM() {
    double vysledek = nastavVstupniJednotkuAPreved("yd");
    assertEquals(0.9144, vysledek, EPS);
  }

}
