package prevodnik.ts_05.ts_05_04;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_04_03 extends Support_05_04 {

  @Test
  public void testPrevodFtNaM() {
    double vysledek = nastavVstupniJednotkuAPreved("ft");
    assertEquals(0.3048, vysledek, EPS);
  }

}
