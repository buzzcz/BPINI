package prevodnik.ts_05.ts_05_04;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_05_04_01.class, TC_05_04_02.class, TC_05_04_03.class, 
                TC_05_04_04.class, TC_05_04_05.class, TC_05_04_06.class, 
                TC_05_04_07.class })

public class TS_05_04 {
  // spousti vsechny TC v teto TS
}
