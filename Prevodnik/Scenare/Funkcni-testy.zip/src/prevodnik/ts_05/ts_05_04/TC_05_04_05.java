package prevodnik.ts_05.ts_05_04;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_04_05 extends Support_05_04 {

  @Test
  public void testPrevodMNaM() {
    double vysledek = nastavVstupniJednotkuAPreved("m");
    assertEquals(1, vysledek, EPS);
  }

}
