package prevodnik.ts_05.ts_05_04;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_04_04 extends Support_05_04 {

  @Test
  public void testPrevodInNaM() {
    double vysledek = nastavVstupniJednotkuAPreved("in");
    assertEquals(0.0254, vysledek, EPS);
  }

}
