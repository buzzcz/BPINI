package prevodnik.ts_05.ts_05_04;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_04_02 extends Support_05_04 {

  @Test
  public void testPrevodDmNaM() {
    double vysledek = nastavVstupniJednotkuAPreved("dm");
    assertEquals(0.1, vysledek, EPS);
  }

}
