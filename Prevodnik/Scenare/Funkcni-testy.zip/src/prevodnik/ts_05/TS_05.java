package prevodnik.ts_05;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import prevodnik.ts_05.ts_05_01.TS_05_01;
import prevodnik.ts_05.ts_05_02.TS_05_02;
import prevodnik.ts_05.ts_05_03.TS_05_03;
import prevodnik.ts_05.ts_05_04.TS_05_04;
import prevodnik.ts_05.ts_05_05.TS_05_05;
import prevodnik.ts_05.ts_05_06.TS_05_06;
import prevodnik.ts_05.ts_05_07.TS_05_07;
import prevodnik.ts_05.ts_05_08.TS_05_08;

@RunWith(Suite.class)
@SuiteClasses({ TS_05_01.class, TS_05_02.class, TS_05_03.class, 
                TS_05_04.class, TS_05_05.class, TS_05_06.class, 
                TS_05_07.class, TS_05_08.class 
  })

public class TS_05 {
  // spousti vsechny TS v teto TS
}
