package prevodnik.ts_05.ts_05_02;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_02_01 extends Support_05_02 {

  @Test
  public void testPrevodCmNaCm() {
    String jednotka = nazvyVyberu.get("cm");
    double vysledek = zapisVyberPreved(jednotka);
    assertEquals(3, vysledek, EPS);
  }

}
