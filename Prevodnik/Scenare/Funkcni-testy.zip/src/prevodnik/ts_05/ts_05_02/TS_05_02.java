package prevodnik.ts_05.ts_05_02;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_05_02_01.class, TC_05_02_02.class, TC_05_02_03.class, 
                TC_05_02_04.class, TC_05_02_05.class, TC_05_02_06.class, 
                TC_05_02_07.class })

public class TS_05_02 {
  // spousti vsechny TC v teto TS
}
