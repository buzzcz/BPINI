package prevodnik.ts_05.ts_05_02;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_02_02 extends Support_05_02 {

  @Test
  public void testPrevodDmNaDm() {
    String jednotka = nazvyVyberu.get("dm");
    double vysledek = zapisVyberPreved(jednotka);
    assertEquals(3, vysledek, EPS);
  }

}
