package prevodnik.ts_05.ts_05_02;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TC_05_02_07 extends Support_05_02 {

  @Test
  public void testPrevodYdNaYd() {
    String jednotka = nazvyVyberu.get("yd");
    double vysledek = zapisVyberPreved(jednotka);
    assertEquals(3, vysledek, EPS);
  }

}
