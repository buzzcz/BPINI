package prevodnik.ts_07;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import prevodnik.ts_07.ts_07_01.TS_07_01;
import prevodnik.ts_07.ts_07_02.TS_07_02;
import prevodnik.ts_07.ts_07_03.TS_07_03;

@RunWith(Suite.class)
@SuiteClasses({ TS_07_01.class, TS_07_02.class, TS_07_03.class, 
  })

public class TS_07 {
  // spousti vsechny TS v teto TS
}
