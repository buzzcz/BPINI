package prevodnik.ts_07.ts_07_02;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_07_02_01.class, TC_07_02_02.class
             })

public class TS_07_02 {
  // spousti vsechny TC v teto TS
}
