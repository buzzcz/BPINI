package prevodnik.ts_07.ts_07_02;

import static org.junit.Assert.assertFalse;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class TC_07_02_02 extends Support_07_02 {
  
  @Test
  public void testVystupniPole_Editovatelnost() {
    WebElement textovePole = driver.findElement(By.id("cisloVystup"));
    String readOnly = textovePole.getAttribute("readonly");
    if (readOnly == null) {
      readOnly = "false";
    }
    boolean editovatelne = (readOnly.equals("true")) ? false : true;
    assertFalse("Vystupni textove je editovatelne", editovatelne);
  }
}
