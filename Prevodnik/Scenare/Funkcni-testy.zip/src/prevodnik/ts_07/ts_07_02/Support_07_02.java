package prevodnik.ts_07.ts_07_02;

import org.junit.BeforeClass;

import prevodnik.ts_07.Support_07;

public class Support_07_02 extends Support_07 {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    Support_07.setUpBeforeClass();
    driver.get(baseUrl);
  }

}
