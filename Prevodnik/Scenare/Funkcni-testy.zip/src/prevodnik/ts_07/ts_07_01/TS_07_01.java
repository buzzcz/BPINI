package prevodnik.ts_07.ts_07_01;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_07_01_01.class, TC_07_01_02.class, TC_07_01_03.class, 
                TC_07_01_04.class, TC_07_01_05.class, TC_07_01_06.class, 
                TC_07_01_07.class, TC_07_01_08.class
             })

public class TS_07_01 {
  // spousti vsechny TC v teto TS
}
