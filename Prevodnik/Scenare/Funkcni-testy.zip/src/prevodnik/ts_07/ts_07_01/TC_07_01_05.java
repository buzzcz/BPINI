package prevodnik.ts_07.ts_07_01;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_07_01_05 extends Support_07_01 {

  private WebElement textovePole;
  
  @Before
  public void setUp() throws Exception {
    textovePole = driver.findElement(By.id("cisloVystup"));
  }
  
  @Test
  public void test_1_VystupniPole_Existence() {
    boolean existuje = (textovePole != null) ? true : false;
    assertTrue("Vystupni textove neexistuje", existuje);
  }
  
  @Test
  public void test_2_VystupniPole_Typ() {
    String typ = textovePole.getAttribute("type");
    assertEquals("Vystupni textove neni typu 'text'", "text", typ);
  }
}
