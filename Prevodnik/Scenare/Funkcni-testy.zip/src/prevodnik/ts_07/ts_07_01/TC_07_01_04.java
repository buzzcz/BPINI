package prevodnik.ts_07.ts_07_01;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_07_01_04 extends Support_07_01 {

  private WebElement label;
  
  @Before
  public void setUp() throws Exception {
    label = driver.findElement(By.id("label_vystup"));
  }
  
  @Test
  public void test_1_LabelVystup_Existence() {
    boolean existuje = (label != null) ? true : false;
    assertTrue("Label Vystup neexistuje", existuje);
  }
  
  @Test
  public void test_2_LabelVystup_Pojmenovani() {
    String jmeno = label.getText();
    assertEquals("Výstup:", jmeno);
  }
}
