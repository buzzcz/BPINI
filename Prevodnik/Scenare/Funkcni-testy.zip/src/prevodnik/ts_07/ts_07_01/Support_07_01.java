package prevodnik.ts_07.ts_07_01;

import org.junit.Before;
import org.junit.BeforeClass;

import prevodnik.ts_07.Support_07;

public class Support_07_01 extends Support_07 {

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    Support_07.setUpBeforeClass();
    driver.get(baseUrl);
  }

}
