package prevodnik.ts_07.ts_07_01;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_07_01_02 extends Support_07_01 {

  private WebElement textovePole;
  
  @Before
  public void setUp() throws Exception {
    textovePole = driver.findElement(By.id("cisloVstup"));
  }
  
  @Test
  public void test_1_VstupniPole_Existence() {
    boolean existuje = (textovePole != null) ? true : false;
    assertTrue("Vstupni textove neexistuje", existuje);
  }
  
  @Test
  public void test_2_VstupniPole_Typ() {
    String typ = textovePole.getAttribute("type");
    assertEquals("Vstupni textove neni typu 'text'", "text", typ);
  }
}
