package prevodnik.ts_07.ts_07_01;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_07_01_08 extends Support_07_01 {

  private WebElement tlacitko;
  
  @Before
  public void setUp() throws Exception {
    tlacitko = driver.findElement(By.name("vymaz"));
  }
  
  @Test
  public void test_1_TlacitkoVymaz_Existence() {
    boolean existuje = (tlacitko != null) ? true : false;
    assertTrue("Tlacitko Vymaž neexistuje", existuje);
  }
  
  @Test
  public void test_2_TlacitkoVymaz_Typ() {
    String typ = tlacitko.getAttribute("type");
    assertEquals("Tlacitko Vymaž neni typu 'submit'", "submit", typ);
  }
  
  @Test
  public void test_3_TlacitkoVymaz_Pojmenovani() {
    String jmeno = tlacitko.getAttribute("value");
    assertEquals("Vymaž", jmeno);
  }
}
