package prevodnik.ts_07.ts_07_01;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_07_01_06 extends Support_07_01 {

  private WebElement seznam;
  
  @Before
  public void setUp() throws Exception {
    seznam = driver.findElement(By.id("jednotkaVystup"));
  }
  
  @Test
  public void test_1_SeznamVystup_Existence() {
    boolean existuje = (seznam != null) ? true : false;
    assertTrue("Vystupni vyberovy seznam neexistuje", existuje);
  }
  
  @Test
  public void test_2_SeznamVystup_Typ() {
    String typ = seznam.getTagName();
    assertEquals("Vystupni vyberovy seznam neni typu 'select'", "select", typ);
  }
}
