package prevodnik.ts_07.ts_07_03;

import static org.junit.Assert.assertEquals;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_07_03_02 extends Support_07_03 {
 
  private WebElement seznam;
  private List<WebElement> vsechnyVolby;
  
  @Before
  public void setUp() throws Exception {
    seznam = driver.findElement(By.id("jednotkaVystup"));
    vsechnyVolby = seznam.findElements(By.tagName("option"));
  }
  
  @Test
  public void test_1_SeznamVystup_PocetPolozek() {
    int pocet = vsechnyVolby.size();
    assertEquals("Vystupni vyberovy seznam nema spravny pocet polozek", 
                nazvyVyberu.size(), pocet);
  }
  
  @Test
  public void test_2_SeznamVystup_JmenaPolozek() {
    Collection<String> spravnaJmena = nazvyVyberu.values();
    
    Set<String> existujiciJmena = new HashSet<String>();
    for (WebElement we : vsechnyVolby ) {
      existujiciJmena.add(we.getText());
    }
    
    Set<String> symetrickyRozdil = new HashSet<String>(spravnaJmena);
    symetrickyRozdil.addAll(existujiciJmena);
    Set<String> tmp = new HashSet<String>(spravnaJmena);
    tmp.retainAll(existujiciJmena);
    symetrickyRozdil.removeAll(tmp);
    String chybiNeboPrebyva = "Chybi nebo prebyva: " + symetrickyRozdil.toString();
    assertEquals(chybiNeboPrebyva, 0, symetrickyRozdil.size());
  }
}
