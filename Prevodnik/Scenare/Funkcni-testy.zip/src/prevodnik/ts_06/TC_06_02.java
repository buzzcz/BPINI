package prevodnik.ts_06;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_06_02 extends Support_06 {

  @Test
  public void test_1_PrevodChyba() {
    // vyber ve Vstup
    WebElement seznam = driver.findElement(By.name("jednotkaVstup"));
    Select jednotkaVstup = new Select(seznam);
    jednotkaVstup.selectByVisibleText(nazvyVyberu.get("m"));  
    
    // vyber ve Vystup
    seznam = driver.findElement(By.name("jednotkaVystup"));
    Select jednotkaVystup = new Select(seznam);
    jednotkaVystup.selectByVisibleText(nazvyVyberu.get("m"));  
    
    // zapis do Vstup 
    WebElement input = driver.findElement(By.id("cisloVstup"));
    input.sendKeys("abc");

    // stisk tlacitka Preved
    driver.findElement(By.name("preved")).click();

    // vyhodnoceni prevodu
    WebElement chyboveHlaseni = driver.findElement(By.id("chyba_0"));
    String hlaseni = chyboveHlaseni.getText();
    assertEquals("Vstupní číslo není validní (není zapsáno v podporovaném formátu nebo obsahuje nepovolené znaky - viz nápověda).", hlaseni);
  }
  
  @Test
  public void test_2_KontrolaChybovehoVypisu() {
    WebElement chyboveHlaseni = driver.findElement(By.id("chyba"));
    assertEquals("Nelze převést", chyboveHlaseni.getText());
  }

  @Test
  public void test_3_VymazPoChybaPrevodu_Vstup() {
    // stisk tlacitka Vymaz
    driver.findElement(By.name("vymaz")).click();
    WebElement vstup = driver.findElement(By.id("cisloVstup"));
    boolean jePrazdny = vstup.getAttribute("value").isEmpty();
    assertTrue("Pole Vstup neni vymazano", jePrazdny);
  }
  
  @Test
  public void test_4_VymazPoChybaPrevodu_Vystup() {
    WebElement vystup = driver.findElement(By.id("cisloVystup"));
    boolean jePrazdny = vystup.getAttribute("value").isEmpty();
    assertTrue("Pole Vystup neni vymazano", jePrazdny);
  }
  
  @Test
  public void test_5_VymazPoOKPrevodu_Vstup_cm() {
    WebElement seznam = driver.findElement(By.id("jednotkaVstup"));
    Select select = new Select(seznam);
    String vybrany = select.getFirstSelectedOption().getText();
    String ocekavany = nazvyVyberu.get("cm");
    assertEquals("Vstupni vyberovy seznam nema vybranu vychozi polozku", 
                   ocekavany, vybrany);
  }
  
  @Test
  public void test_6_VymazPoOKPrevodu_Vystup_cm() {
    WebElement seznam = driver.findElement(By.id("jednotkaVystup"));
    Select select = new Select(seznam);
    String vybrany = select.getFirstSelectedOption().getText();
    String ocekavany = nazvyVyberu.get("cm");
    assertEquals("Vystupni vyberovy seznam nema vybranu vychozi polozku", 
                   ocekavany, vybrany);
  }
}
