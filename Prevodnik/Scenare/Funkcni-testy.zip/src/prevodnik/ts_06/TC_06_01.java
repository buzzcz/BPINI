package prevodnik.ts_06;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_06_01 extends Support_06 {

  @Test
  public void test_1_PrevodOK() {
    // zapis do Vstup 
    WebElement input = driver.findElement(By.id("cisloVstup"));
    input.sendKeys("1");

    // vyber in (palec) ve Vstup
    WebElement seznam = driver.findElement(By.name("jednotkaVstup"));
    Select jednotkaVstup = new Select(seznam);
    jednotkaVstup.selectByVisibleText(nazvyVyberu.get("in"));  

    // vyber mm (milimetr) ve Vystup
    seznam = driver.findElement(By.name("jednotkaVystup"));
    Select jednotkaVystup = new Select(seznam);
    jednotkaVystup.selectByVisibleText(nazvyVyberu.get("mm"));  
    
    // stisk tlacitka Preved
    driver.findElement(By.name("preved")).click();

    // vyhodnoceni prevodu
    WebElement vystup = driver.findElement(By.id("cisloVystup"));
    double vysledek = Double.parseDouble(vystup.getAttribute("value"));
    assertEquals(25.4, vysledek, EPS);
  }

  @Test
  public void test_2_VymazPoOKPrevodu_Vstup() {
    // stisk tlacitka Vymaz
    driver.findElement(By.name("vymaz")).click();
    WebElement vstup = driver.findElement(By.id("cisloVstup"));
    boolean jePrazdny = vstup.getAttribute("value").isEmpty();
    assertTrue("Pole Vstup neni vymazano", jePrazdny);
  }
  
  @Test
  public void test_3_VymazPoOKPrevodu_Vystup() {
    WebElement vystup = driver.findElement(By.id("cisloVystup"));
    boolean jePrazdny = vystup.getAttribute("value").isEmpty();
    assertTrue("Pole Vystup neni vymazano", jePrazdny);
  }
  
  @Test
  public void test_4_VymazPoOKPrevodu_Vstup_cm() {
    WebElement seznam = driver.findElement(By.id("jednotkaVstup"));
    Select select = new Select(seznam);
    String vybrany = select.getFirstSelectedOption().getText();
    String ocekavany = nazvyVyberu.get("cm");
    assertEquals("Vstupni vyberovy seznam nema vybranu vychozi polozku", 
                   ocekavany, vybrany);
  }
  
  @Test
  public void test_5_VymazPoOKPrevodu_Vystup_cm() {
    WebElement seznam = driver.findElement(By.id("jednotkaVystup"));
    Select select = new Select(seznam);
    String vybrany = select.getFirstSelectedOption().getText();
    String ocekavany = nazvyVyberu.get("cm");
    assertEquals("Vystupni vyberovy seznam nema vybranu vychozi polozku", 
                   ocekavany, vybrany);
  }
}
