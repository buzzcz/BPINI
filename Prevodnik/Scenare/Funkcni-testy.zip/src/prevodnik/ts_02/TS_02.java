package prevodnik.ts_02;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_02_01.class, TC_02_02.class, TC_02_03.class,
                TC_02_04.class
             })

public class TS_02 {
  // spousti vsechny TC v teto TS
}
