package prevodnik.ts_02;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_02_02 extends Support_02 {

  @Test
  public void test_1_OdkazKIVOKS() {
    WebElement we = driver.findElement(By.linkText("Ověřování kvality software (KIV/OKS)"));
    we.click();

    // cekani
    (new WebDriverWait(driver, 5)).until(
        ExpectedConditions.titleIs(TITULEK_OKS));
        
    assertEquals("https://portal.zcu.cz/portal/prohlizeni.html", driver.getCurrentUrl());
  }

  @Test
  public void test_2_TitulekStranky() {
    assertEquals(TITULEK_OKS, driver.getTitle());
  }
}
