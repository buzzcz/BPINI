package prevodnik.ts_02;

import org.junit.Before;
import org.junit.BeforeClass;

import prevodnik.PrevodnikSupport;

public class Support_02 extends PrevodnikSupport {
  
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    PrevodnikSupport.setUpBeforeClass();
    baseUrl = "http://oks.kiv.zcu.cz/Prevodnik/Uvod";
    driver.get(baseUrl);
 }
  
}
