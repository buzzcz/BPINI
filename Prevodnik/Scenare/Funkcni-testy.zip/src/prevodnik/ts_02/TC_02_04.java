package prevodnik.ts_02;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_02_04 extends Support_02 {

  @Test
  public void test_1_OdkazKIVOKS() {
    WebElement we = driver.findElement(By.linkText("Západočeské univerzitě v Plzni"));
    we.click();

    // cekani
    (new WebDriverWait(driver, 5)).until(
        ExpectedConditions.titleIs(TITULEK_ZCU));
        
    assertEquals("http://www.zcu.cz/", driver.getCurrentUrl());
  }

  @Test
  public void test_2_TitulekStranky() {
    assertEquals(TITULEK_ZCU, driver.getTitle());
  }
}
