package prevodnik.ts_04;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TC_04_01.class, TC_04_02.class
             })

public class TS_04 {
  // spousti vsechny TC v teto TS
}
