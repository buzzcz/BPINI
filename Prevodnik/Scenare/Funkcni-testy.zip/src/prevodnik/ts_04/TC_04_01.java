package prevodnik.ts_04;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_04_01 extends Support_04 {

  @Test
  public void test_1_OdkazReklama() {
    WebElement we = driver.findElement(By.id("reklama_kiv"));
    we.click();

    // cekani
    (new WebDriverWait(driver, 5)).until(
        ExpectedConditions.titleIs(TITULEK_KIV));
        
    assertEquals("http://www.kiv.zcu.cz/", driver.getCurrentUrl());
  }

  @Test
  public void test_2_TitulekStranky() {
    assertEquals(TITULEK_KIV, driver.getTitle());
  }
}
