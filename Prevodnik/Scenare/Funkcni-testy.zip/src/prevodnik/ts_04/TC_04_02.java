package prevodnik.ts_04;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TC_04_02 extends Support_04 {

  @Test
  public void test_1_ZalozkaPrevodnik() {
    WebElement we = driver.findElement(By.linkText("stránce s převodníkem"));
    we.click();

    // cekani
    (new WebDriverWait(driver, 5)).until(
        ExpectedConditions.titleIs("PřeVODNÍK"));
        
    assertEquals("http://oks.kiv.zcu.cz/Prevodnik/Prevodnik", driver.getCurrentUrl());
  }

  @Test
  public void test_2_TitulekStranky() {
    assertEquals("PřeVODNÍK", driver.getTitle());
  }
}
